import React, { useRef, useState, useEffect } from 'react';
import { RefreshCw, Check, ChevronDown, Camera as CameraIcon, X, RefreshCcw } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (base64: string) => void;
  onClose?: () => void; // Optional close handler if needed
}

export const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);
  
  const [availableDevices, setAvailableDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');

  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    streamRef.current = stream;
  }, [stream]);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      setStream(null);
      streamRef.current = null;
    }
  };

  const startCamera = async (deviceId?: string) => {
    stopCamera();
    try {
      const constraints: MediaStreamConstraints = { 
        video: { 
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          deviceId: deviceId ? { exact: deviceId } : undefined,
          // Only fallback to user facing if NO device ID is specified to avoid conflict
          ...(!deviceId && { facingMode: "user" }) 
        } 
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setError(null);
    } catch (err) {
      setError("无法访问相机，请确保已授予权限。");
      console.error(err);
    }
  };

  const refreshDevices = async () => {
    try {
      // 1. Ensure we have permission by requesting a temp stream if needed, 
      // but usually we are already running.
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(d => d.kind === 'videoinput');
      setAvailableDevices(videoDevices);
      return videoDevices;
    } catch (e) {
      console.error("Failed to enumerate devices", e);
      return [];
    }
  };

  // Initial setup
  useEffect(() => {
    const init = async () => {
      try {
        // Request permission first
        const tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
        
        const videoDevices = await refreshDevices();
        
        // Stop temp stream
        tempStream.getTracks().forEach(track => track.stop());

        // Default logic: Index 2 for Mac if available
        let targetId = '';
        if (videoDevices.length > 0) {
            const indexToUse = videoDevices.length > 2 ? 2 : 0;
            targetId = videoDevices[indexToUse].deviceId;
        }

        setSelectedDeviceId(targetId);
        startCamera(targetId);

      } catch (err) {
        console.error("Error initializing camera:", err);
        startCamera(); // Try default
      }
    };

    init();
    
    // Listen for device changes (plugging in iPhone, etc.)
    const handleDeviceChange = async () => {
      const videoDevices = await refreshDevices();
      // Optionally switch if the current device is no longer available
    };
    navigator.mediaDevices.addEventListener('devicechange', handleDeviceChange);

    return () => {
      stopCamera();
      navigator.mediaDevices.removeEventListener('devicechange', handleDeviceChange);
    };
  }, []);

  const handleDeviceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const newDeviceId = e.target.value;
      setSelectedDeviceId(newDeviceId);
      startCamera(newDeviceId);
  };

  const handleCapture = () => {
    // Trigger visual flash
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 150);

    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Correctly handle mirroring
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0);
        
        const base64 = canvas.toDataURL('image/jpeg', 0.95);
        setCapturedImage(base64);
      }
    } else {
      console.error("Capture failed: Missing video or canvas ref");
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    if (!streamRef.current) {
        startCamera(selectedDeviceId);
    }
  };

  const handleConfirm = () => {
    if (capturedImage) {
      stopCamera();
      onCapture(capturedImage);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center animate-in fade-in duration-300">
      
      {/* Hidden Canvas for Capture Logic - CRITICAL FIX */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Flash Effect Overlay */}
      {isFlashing && (
        <div className="absolute inset-0 z-[60] bg-white animate-out fade-out duration-150 pointer-events-none" />
      )}
      
      {/* Full Screen Video Feed */}
      <div className="absolute inset-0 w-full h-full">
        <video 
          ref={videoRef}
          autoPlay 
          playsInline 
          muted
          className={`w-full h-full object-cover transform -scale-x-100 ${capturedImage ? 'hidden' : 'block'}`}
        />
        {capturedImage && (
          <img 
            src={capturedImage} 
            alt="Capture" 
            className="w-full h-full object-cover"
          />
        )}
      </div>

      {/* Top Controls Overlay */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start z-10 bg-gradient-to-b from-black/60 to-transparent">
        <button 
          onClick={onClose || (() => window.location.reload())} // Fallback reload if no close provided
          className="p-2 rounded-full bg-black/30 backdrop-blur-md text-white hover:bg-white/20 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {!capturedImage && (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => { refreshDevices(); }}
              className="p-2 rounded-full bg-black/30 backdrop-blur-md text-white hover:bg-white/20 transition-colors"
              title="刷新设备列表"
            >
              <RefreshCcw className="w-5 h-5" />
            </button>
            {availableDevices.length > 0 && (
              <div className="relative group/select">
                 <select
                    value={selectedDeviceId}
                    onChange={handleDeviceChange}
                    className="appearance-none bg-black/30 backdrop-blur-md text-white pl-10 pr-10 py-2 rounded-full border border-white/20 hover:bg-black/50 hover:border-white/40 focus:outline-none focus:border-indigo-500 text-sm cursor-pointer transition-all"
                  >
                    {availableDevices.map((device, index) => (
                      <option key={device.deviceId || index} value={device.deviceId} className="bg-zinc-900 text-white">
                        {device.label || `摄像头 ${index + 1}`}
                      </option>
                    ))}
                  </select>
                  <CameraIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/90 pointer-events-none" />
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/70 pointer-events-none" />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Controls Overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-8 flex justify-center items-center z-10 bg-gradient-to-t from-black/80 to-transparent">
        {!capturedImage ? (
          <button
            onClick={handleCapture}
            className="group relative flex items-center justify-center w-20 h-20 rounded-full border-4 border-white hover:border-indigo-400 hover:scale-105 transition-all shadow-lg shadow-black/50"
          >
            <div className="w-16 h-16 bg-white rounded-full group-hover:bg-indigo-400 transition-colors" />
          </button>
        ) : (
          <div className="flex gap-6 animate-in slide-in-from-bottom-4 fade-in">
            <button
              onClick={handleRetake}
              className="flex items-center gap-2 px-6 py-3 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-medium transition-colors border border-white/10"
            >
              <RefreshCw className="w-5 h-5" />
              重拍
            </button>
            <button
              onClick={handleConfirm}
              className="flex items-center gap-2 px-8 py-3 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-xl shadow-indigo-500/25 transition-all transform hover:scale-105"
            >
              <Check className="w-5 h-5" />
              使用照片
            </button>
          </div>
        )}
      </div>
    </div>
  );
};