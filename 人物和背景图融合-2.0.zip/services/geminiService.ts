
import { GoogleGenAI, Modality } from "@google/genai";

// Enhanced cleaner to remove all metadata and whitespace
const cleanBase64 = (base64: string) => {
  return base64.replace(/^data:(image|audio|video)\/[\w-+\.]+;base64,/, '').replace(/\s/g, '');
};

const getAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("请先选择并连接 API Key。");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateComposite = async (bgBase64: string, selfieBase64: string): Promise<string> => {
  const ai = getAI();
  try {
    const prompt = `
      ROLE: Master Cinematic Compositor & Portrait Photographer.
      TASK: Harmoniously composite the [Person] into the [Background] with extreme photorealistic quality.

      ANATOMY & IDENTITY RULES (CRITICAL):
      1. PERFECT ANATOMY: Ensure the subject has a symmetrical face and perfect anatomical structure. 
      2. ZERO DISTORTION: Avoid distorted faces, melting features, or asymmetrical eyes.
      3. IDENTITY PRESERVATION: The person's unique facial identity must remain 100% consistent with the source.
      4. VIEWPOINT: Render the person in a Front view or 3/4 view. Avoid extreme high or low camera angles.
      5. NO ARTIFICE: Strictly avoid cartoon, illustration, or stylized looks. Output must be photorealistic.

      COMPOSITION & LIGHTING:
      1. CINEMATIC LIGHTING: Match the light direction, intensity, and color temperature of the background exactly.
      2. SEAMLESS BLENDING: Apply realistic shadows, rim lighting, and ambient occlusion to ground the person.
      3. CAMERA CHARACTERISTICS: Match the depth-of-field, grain, and lens characteristics of the background image.
      
      OUTPUT: A 2K high-fidelity photographic masterpiece.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          { text: prompt },
          { 
            inlineData: { 
              mimeType: 'image/jpeg', 
              data: cleanBase64(bgBase64) 
            } 
          },
          { 
            inlineData: { 
              mimeType: 'image/jpeg', 
              data: cleanBase64(selfieBase64) 
            } 
          },
        ],
      },
      config: {
        temperature: 0.2,
        topP: 0.3,
        seed: 42,
        responseModalities: [Modality.IMAGE],
        imageConfig: {
           aspectRatio: "16:9", 
           imageSize: "2K",     
        }
      },
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
      for (const part of parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("Gemini 未能生成有效的图像内容。");
  } catch (error: any) {
    console.error("Gemini Composition Error:", error);
    if (error.message === "Failed to fetch") {
      throw new Error("Gemini 服务连接失败，请检查 API Key 或网络环境。");
    }
    throw error;
  }
};

export const editImage = async (imageBase64: string, userPrompt: string): Promise<string> => {
  const ai = getAI();
  try {
    const prompt = `
      ROLE: High-End Image Retoucher.
      TASK: Perform the following edit: "${userPrompt}".
      
      STRICT CONSTRAINTS:
      - MAINTAIN ANATOMY: Ensure photorealistic skin textures and perfect facial symmetry.
      - AVOID ARTIFACTS: No melting faces, bad eyes, or distorted limbs.
      - IDENTITY: The subject's face must remain recognizable and unchanged in geometry.
      - STYLE: Maintain 2K cinematic realism. No illustration or cartoon filters.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          { text: prompt },
          { 
            inlineData: { 
              mimeType: 'image/png', 
              data: cleanBase64(imageBase64) 
            } 
          },
        ],
      },
      config: {
        temperature: 0.2,
        topP: 0.3,
        seed: 42,
        responseModalities: [Modality.IMAGE],
        imageConfig: {
           aspectRatio: "16:9", 
           imageSize: "2K",     
        }
      },
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
      for (const part of parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("重绘处理未能生成新图像。");
  } catch (error: any) {
    console.error("Gemini Edit Error:", error);
    throw error;
  }
};

export const upscaleImage = async (imageBase64: string): Promise<string> => {
  const ai = getAI();
  try {
    const prompt = `
      ROLE: Professional AI Upscaler & Restoration Specialist.
      TASK: Re-generate this image at native 2K resolution with enhanced photorealistic detail.
      
      INSTRUCTIONS:
      1. ANATOMICAL PRECISION: Fix any slight facial asymmetries or artifacts. Ensure perfect eyes and skin texture.
      2. PRESERVE IDENTITY: Do not change the core facial features. 
      3. DETAIL ENHANCEMENT: Sharpen edges, remove noise, and add high-frequency textures (skin pores, fabric weave).
      4. STYLE: Must be pure photorealism. No distorted or cartoonish elements.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          { text: prompt },
          { 
            inlineData: { 
              mimeType: 'image/png', 
              data: cleanBase64(imageBase64) 
            } 
          },
        ],
      },
      config: {
        temperature: 0.2,
        topP: 0.3,
        seed: 42,
        responseModalities: [Modality.IMAGE],
        imageConfig: {
            imageSize: '2K', 
            aspectRatio: "16:9" 
        }
      },
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
      for (const part of parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("超分处理未能成功。");
  } catch (error: any) {
    console.error("Gemini Upscale Error:", error);
    throw error;
  }
};

export const transcribeAudio = async (audioBase64: string): Promise<string> => {
  const ai = getAI();
  try {
    const prompt = "Transcribe this audio command for image editing precisely. Output only the plain text transcription.";

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: 'audio/webm',
              data: cleanBase64(audioBase64)
            }
          }
        ]
      },
      config: {
        temperature: 0,
        topP: 0.3,
      }
    });

    return response.text?.trim() || "";
  } catch (error: any) {
    console.error("Gemini Transcription Error:", error);
    throw new Error("语音识别失败，请检查麦克风权限或重试。");
  }
};
